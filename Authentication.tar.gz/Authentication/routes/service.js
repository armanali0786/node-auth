const express = require('express');

const serviceController = require('../controllers/service');

const router = express.Router();


router.get('/add-service' , serviceController.getService)


router.post('/add-service' , serviceController.postservice)


router.get('/servicelist' , serviceController.getSercivelist)

// router.post('/servicelist' , serviceController.postServicelist)

module.exports = router;