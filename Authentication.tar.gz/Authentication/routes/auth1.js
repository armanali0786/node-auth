const express = require('express');
const {check,body} =require('express-validator/check');

const authController = require('../controllers/auth');

const router = express.Router();

router.get('/login', authController.getLogin);

router.get('/otp-form' ,authController.getOtp);
router.post('/otp-form' ,authController.postOtp)

router.get('/signup', authController.getSignup);

router.post('/login', authController.postLogin);
//validation
router.post('/signup',[check('email')
.isEmail()
.withMessage('INVALID EMAIL').custom((value,{req})=>{
   if(value=='test@test.com'){
    throw new Error('This email is Forbidden')
   } 
   return true;


}),body('password', 'please enter a valid password')
.isLength({min:5}).isAlphanumeric(),
body('confirmPassword').custom((value ,{req})=>{
    if (value !==req.body.password){
throw new Error('PAssword Have to matched')
    }
    return true;
})
]
 , authController.postSignup);

router.post('/logout', authController.postLogout);

router.get('/reset' , authController.getReset)
router.post('/reset' , authController.postReset)
module.exports = router;