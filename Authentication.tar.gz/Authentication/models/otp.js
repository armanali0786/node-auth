const mongoose = require('mongoose');
const bcrypt =require ('bcrypt');
const { INTEGER } = require('sequelize');
const { STRING } = require('sequelize');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  

});
module.exports = mongoose.model('Otp', userSchema);