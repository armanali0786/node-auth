const { ObjectID } = require('mongodb');
const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const serviceSchema = new Schema({
name: {
    type: String,
    required: true
  },
  number: {
    type: Number,
    required: true
  },
  pickdate: {
    type: String,
    required: true
  },
  location: {
    type: String,
    
  },
  price:{
       type:Number,
       required:true
  },
  veichelservice :{
    type:String,
    
  },
  dropdate :{
type:String,

  },
  userID: {
    type: Schema.Types.ObjectId,
    ref: 'User',
   
  }
});

module.exports = mongoose.model('Service', serviceSchema);